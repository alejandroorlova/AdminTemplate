import { Component } from '@angular/core';

@Component({
  selector: 'app-table-cell',
  imports: [],
  templateUrl: './table-cell.component.html',
  styleUrl: './table-cell.component.scss'
})
export class TableCellComponent {

}
